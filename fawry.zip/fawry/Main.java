import models.*;
import users.*;
import services.*;

public class Main {
    public static void main(String[] args) {
        Product cheese = new ExpirableShippableProduct("Cheese", 100, 5, false, 200);
        Product tv = new ShippableProduct("TV", 5000, 5, 10000);
        Product scratchCard = new Product("Mobile Scratch Card", 50, 10) {};

        Customer customer = new Customer("Fares", 20000); 
        Cart cart = new Cart();

        cart.add(cheese, 2); 
        cart.add(tv, 3); 
        cart.add(scratchCard, 1); 

        Checkout.process(customer, cart);
    }
}
