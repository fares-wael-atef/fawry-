package services;

import java.util.*;
import models.Product;
import users.Cart;
import users.Customer;
import interfaces.Shippable;

public class Checkout {
    public static void process(Customer customer, Cart cart) {
        if (cart.isEmpty()) {
            System.err.println("Cart is empty.");
            return;
        }

        double subtotal = 0;
        List<Shippable> toShip = new ArrayList<>();

        for (Map.Entry<Product, Integer> entry : cart.getItems().entrySet()) {
            Product p = entry.getKey();
            int qty = entry.getValue();

            if (p.isExpired()) {
                System.err.println(p.getName() + " is expired.");
                return;
            }
            if (qty > p.getQuantity()) {
                System.err.println(p.getName() + " is out of stock.");
                return;
            }

            subtotal += p.getPrice() * qty;
            if (p.requiresShipping()) {
                for (int i = 0; i < qty; i++)
                    toShip.add((Shippable) p);
            }
        }

        double shipping = toShip.isEmpty() ? 0 : 30;
        double total = subtotal + shipping;

        if (customer.getBalance() < total) {
            System.err.println("Insufficient balance.");
            return;
        }

        customer.deduct(total);
        for (Map.Entry<Product, Integer> entry : cart.getItems().entrySet()) {
            entry.getKey().decreaseQuantity(entry.getValue());
        }

        if (!toShip.isEmpty()) ShippingService.shipItems(toShip);

        System.out.println("\n** Checkout receipt **");
        for (Map.Entry<Product, Integer> entry : cart.getItems().entrySet()) {
            Product p = entry.getKey();
            int qty = entry.getValue();
            System.out.printf("%dx %s\t%.0f%n", qty, p.getName(), p.getPrice() * qty);
        }
        System.out.println("----------------------");
        System.out.printf("Subtotal\t%.0f%n", subtotal);
        System.out.printf("Shipping\t%.0f%n", shipping);
        System.out.printf("Amount\t\t%.0f%n", total);
        // System.out.printf("Customer Balance\t%.0f%n", customer.getBalance());
    }
}
