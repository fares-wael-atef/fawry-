package services;

import java.util.*;
import interfaces.Shippable;

public class ShippingService {
    public static void shipItems(List<Shippable> items) {
        System.out.println("** Shipment notice **");

        Map<String, Double> weightMap = new LinkedHashMap<>();
        Map<String, Integer> countMap = new LinkedHashMap<>();

        for (Shippable item : items) {
            String name = item.getName();
            weightMap.put(name, weightMap.getOrDefault(name, 0.0) + item.getWeight());
            countMap.put(name, countMap.getOrDefault(name, 0) + 1);
        }

        double totalWeight = 0;
        for (String name : countMap.keySet()) {
            int count = countMap.get(name);
            double weight = weightMap.get(name);
            System.out.printf("%dx %s\t%.0fg%n", count, name, weight);
            totalWeight += weight;
        }

        System.out.printf("Total package weight %.1fkg%n\n", totalWeight / 1000.0);
    }
}
